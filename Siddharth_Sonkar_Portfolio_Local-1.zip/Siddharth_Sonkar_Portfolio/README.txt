SIDDHARTH SONKAR — LOCAL PORTFOLIO

Files:
- index.html: portfolio content
- style.css: visual design and responsive layout
- script.js: particles and animations

HOW TO PREVIEW ON ANDROID:
1. Extract this ZIP using your phone's Files app.
2. Open the extracted folder and tap index.html.
3. If it opens as text or does not run correctly, use an HTML preview/editor app or open the folder in a code editor with preview support.
4. The Google Fonts import needs internet; the rest of the design is local.

IMPORTANT:
- This is a private local draft; it has NOT been published.
- GitHub and LinkedIn links point to the profile URLs supplied in the resume.
- No resume PDF/download button is included yet.
- Add a verified GitHub repository/demo link to the project when available.
- Contact email is set to sonkarsidd6142@gmail.com.
